﻿using ChromeServiceReference;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ChromeDataADS
{
    internal class ChromeSubdivisions
    {
        private readonly DatabaseManager db;
        private ChromeServiceReference.AccountInfo accountInfo;

        public ChromeSubdivisions(ChromeServiceReference.AccountInfo accountInfo, DatabaseManager db)
        {
            this.db = db;
            this.accountInfo = accountInfo;
        }
        public void LoadSubdivisionsByYear(int modelYear)
        {
            if (modelYear < 1990) //  not valid
            {
                Console.WriteLine("Skipped Chrome ADS. Year should be after 1989.");
                Logger.Instance.Write("Skipped Chrome ADS. Year should be after 1989.");
                return;
            }
            Task<getSubdivisionsResponse> subdivisionsResponse = GetSubdivisions(modelYear);
            subdivisionsResponse.Wait();
            if (subdivisionsResponse.Result.Subdivisions.responseStatus.responseCode == ResponseStatusResponseCode.Successful)
                ProcessSubdivisions(modelYear, subdivisionsResponse.Result.Subdivisions.subdivision);

        }

        private void ProcessSubdivisions(int modelYear, IdentifiedString[] identifiedStrings)
        {
            List<Subdivision> subdivisions = new List<Subdivision>();
            foreach (IdentifiedString identifiedString in identifiedStrings)
            {
                subdivisions.Add(new Subdivision
                {
                    Year = modelYear,
                    SubdivisionId = identifiedString.id,
                    SubdivisionName = identifiedString.Value
                });
            }
            db.InsertSubdivisions(subdivisions);
        }

        private async Task<getSubdivisionsResponse> GetSubdivisions(int modelYear)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            SubdivisionsRequest req = new SubdivisionsRequest
            {
                accountInfo = accountInfo
            };
            req.modelYear = modelYear;

            getSubdivisionsResponse result = await client.getSubdivisionsAsync(req);
            return result;

        }

    }
}