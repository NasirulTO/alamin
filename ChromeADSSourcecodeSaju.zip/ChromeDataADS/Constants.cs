﻿using System;
using System.Collections.Generic;
using System.Text;
using ChromeCompareServiceReference;

namespace ChromeDataADS
{
    public static class Helper
    {
        public static ChromeServiceReference.AccountInfo ADSAccountInfo = new ChromeServiceReference.AccountInfo
        {
                number = "298803",
                secret = "f0a49ab999b64a69",
                country = "CA",
                behalfOf = "EZ",
                language = "en"
        };

        public static ChromeCompareServiceReference.AccountInfo ChromeConstructAccountInfo = new ChromeCompareServiceReference.AccountInfo
        {
            accountNumber = "298803",
            accountSecret = "f0a49ab999b64a69",
            locale = new Locale { country = "CA", language = "EZ" },
        };

    }
    public enum StandardEquipmentType
    {
        Mechanical = 1,
        Exterior,
        Interior,
        Entertainment,
        Safety,
        Unknown
    }
    public enum DescribeVehicleResponseStatus
    {
        Successful = 1,
        ConditionallySuccessful,
        Unsuccessful
    }
    public enum StockImageType
    {
        view = 1,
        colorized,
        Unknown
    }
    public enum ColorType
    {
        Exterior = 1,
        Interior,
        UnKnown
    }

}
