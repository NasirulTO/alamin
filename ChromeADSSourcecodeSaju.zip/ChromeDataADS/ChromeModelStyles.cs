﻿using ChromeServiceReference;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ChromeDataADS
{
    internal class ChromeModelStyles
    {
        private readonly DatabaseManager db;
        private ChromeServiceReference.AccountInfo accountInfo;

        public ChromeModelStyles(ChromeServiceReference.AccountInfo accountInfo, DatabaseManager db)
        {
            this.db = db;
            this.accountInfo = accountInfo;
        }
        public void LoadModelStylesByYear(int year)
        {
            List<int> modelIds = db.GetModelIds(year);
            foreach(int modelId in modelIds)
            {
                LoadModelStylesByModelId(modelId);
            }
        }
        public void LoadModelStylesByModelId(int modelId)
        {
            if (modelId < 1) //  not valid
            {
                Console.WriteLine("Skipped Chrome ADS. ModelId should be > 0.");
                Logger.Instance.Write("Skipped Chrome ADS. ModelId should be > 0.");
                return;
            }
            Task<getStylesResponse> modelsResponse = GetStylesFromModel(modelId);
            modelsResponse.Wait();
            if (modelsResponse.Result.Styles.responseStatus.responseCode == ResponseStatusResponseCode.Successful)
                ProcessModels(modelId, modelsResponse.Result.Styles.style);

        }

        private void ProcessModels(int modelId, IdentifiedString[] identifiedStrings)
        {
            List<ModelStyle> modelstyle = new List<ModelStyle>();
            foreach (IdentifiedString identifiedString in identifiedStrings)
            {
                modelstyle.Add(new ModelStyle
                {
                    ModelId = modelId,
                    StyleId = identifiedString.id,
                    StyleName = identifiedString.Value
                });
            }
            db.InsertModelStyles(modelstyle);
        }

        private async Task<getStylesResponse> GetStylesFromModel(int modelId)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            StylesRequest req = new StylesRequest
            {
                accountInfo = accountInfo
            };
            req.modelId = modelId;
            getStylesResponse result = await client.getStylesAsync(req);
            return result;

        }

    }
}