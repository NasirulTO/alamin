﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ChromeDataADS
{
    public class Logger
    {
        private static readonly Logger _instance = new Logger();
        private Logger()
        {

        }

        /// <summary>
        /// static object 
        /// </summary>
        public static Logger Instance
        {
            get { return _instance; }
        }

        /// <summary>
        /// write method 
        /// </summary>
        /// <param name="Message"></param>
        public void Write(String Message)
        {
            string logdir = @"d:\ezlogs\"; 
            Message = Environment.NewLine + String.Format("{0:dd-MMM-yyyy hh:mm:ss tt}", DateTime.Now) + "\t=> " + Message;
            if (Directory.Exists(logdir))
            {
                File.AppendAllText(String.Format(@"{0}{1:yyyy_MM}_Chrome_ADS.Log", logdir, DateTime.Now), Message);
            }
            else
            {
                File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + "ChromeADS.log", Message);
            }
            Console.Write(Message);
        }
    }
}
