﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ChromeServiceReference;
using ChromeCompareServiceReference;
using System.IO;

namespace ChromeDataADS
{
    class Program
    {

    static void Main(string[] args)
        {
            // no arugument or first argument is help then show HelpText
            string opt, userid, pwd;
            opt = userid = pwd = "";
            if (args.Length == 0 || args[0].ToUpper() == "HELP" )
            {
                PrintHelpText();
                return;
            }
            opt = args[0].Trim().ToUpper();
            if (opt == "LIVE" || opt == "EZTEST" || opt == "DEV") { }
            else
            {
                PrintHelpText();
                return;
            }
            // live system expects userid and pwd for connection string
            // eg. c:\> dotnet ChromeDataADS.dll LIVE UserLive frfUU$ff

            if (opt == "LIVE")
            {
                if (args.Length==3)
                {
                    userid = args[1].Trim();
                    pwd = args[2].Trim();
                }
                else
                {
                    Console.WriteLine("Must provide username and password for the live connection string");
                    PrintHelpText();
                    return;
                }
            }

            DatabaseManager db = new DatabaseManager(opt,userid,pwd);
           /**/
            ChromeVinDecoder decoder = new ChromeVinDecoder(Helper.ADSAccountInfo, db);
            //decoder.DecodeAllAssets(19);
            // List<int> assets = new List<int> {  602507, 594152,594163,594165,594169,596825,597092  }; 594174
            List<int> assets = new List<int>() { 594174 };//, 466940, 466987, 466532, 466531, 466530, 466527 };466920
            //decoder.DecodeAssetsAndUpdateDB(19, assets);
            decoder.DecodeAssetsAndUpdateDB(19); //19 is test dealerid
            /**/
            //ChromeCompareStyleIdDecode decoder1 = new ChromeCompareStyleIdDecode(Helper.ChromeConstructAccountInfo, db);
            //decoder1.LoadStyleInformation(101697);
            //decoder1.LoadStyleInformation(319634);
            //decoder1.LoadStyleInformation(338366);
            //decoder1.LoadStyleInformation(362454);
            //decoder1.LoadStyleInformation(394262);
            //decoder1.LoadStyleInformation(395665);
            //decoder1.LoadStyleInformation(397254);
            //decoder1.LoadStyleInformation(391775);
            /*
            ChromeDivisions div = new ChromeDivisions(ezAccountInfo, db);
            
            for (int y = 2019; y > 1999; y--)
            {
                div.LoadDivisionsByYear(y);
                Console.WriteLine($"year={y}");
            }
            ChromeSubdivisions subdiv = new ChromeSubdivisions(ezAccountInfo, db);
            for (int y = 2019; y > 1999; y--)
            {
                subdiv.LoadSubdivisionsByYear(y);
                Console.WriteLine($"year={y}");
            }
            ChromeModels models = new ChromeModels(ezAccountInfo, db);
            for (int y = 2019; y > 1999; y--)
            {
                models.LoadModelsByYear(y);
                Console.WriteLine($"year={y}");
            }
            ChromeModelStyles modelStyles = new ChromeModelStyles(ezAccountInfo, db);
            modelStyles.LoadModelStylesByYear(2019);
            modelStyles.LoadModelStylesByYear(2018);
            modelStyles.LoadModelStylesByYear(2017);
            */
        }

        private static void PrintHelpText()
        {
            Console.WriteLine("");
            Console.WriteLine("ChromeData Client Utility");
            Console.WriteLine("===========================================================================================");
            Console.WriteLine("This ChromeData Client Utility will decode VINs and populate database");
            Console.WriteLine(@"c:\> dotnet ChromeDataADS.dll LIVE userid password   -> Run the utility on the live server");
            Console.WriteLine(@"c:\> dotnet ChromeDataADS.dll EZTEST                 -> Run the utility on the EZTEST server");
            Console.WriteLine(@"c:\> dotnet ChromeDataADS.dll dev                    -> Run the utility on the dev server");
            Console.WriteLine(@"c:\> dotnet ChromeDataADS.dll                        -> Run the utility on the dev server");
            Console.WriteLine("===========================================================================================");
            Console.WriteLine("");
            Console.WriteLine("");
        }
    }
}
