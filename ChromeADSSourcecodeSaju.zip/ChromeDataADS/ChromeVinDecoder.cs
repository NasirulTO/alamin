﻿using ChromeServiceReference;
using ChromeCompareServiceReference;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ChromeDataADS
{
    public class ChromeVinDecoder
    {
        DatabaseManager db;
        ChromeServiceReference.AccountInfo accountInfo;
        public ChromeVinDecoder(ChromeServiceReference.AccountInfo accountInfo, DatabaseManager db)
        {
            this.accountInfo = accountInfo;
            this.db = db;
        }
        public void DecodeAssetsAndUpdateDB(int dealerId)
        {
            List<Asset> assetList = db.GetAssetList(dealerId);
            foreach (var asset in assetList)
            {
                DecodeAssetAndUpdateDB(asset);
            }
        }
        public void DecodeAssetsAndUpdateDB(int dealerId, List<int> assetidList)
        {
            List<Asset> assetList = db.GetAssetList(dealerId, assetidList);
            foreach (var asset in assetList)
            {
                DecodeAssetAndUpdateDB(asset);
            }
        }
        public void DecodeAssetAndUpdateDB(Asset asset)
        {
            if (asset.StyleId > 1) // null or not valid
            {
                Logger.Instance.Write($"Skipped Chrome ADS. Vehicle already decoded( AssetId={asset.AssetId},VIN = {asset.Vin}, StyleId = {asset.StyleId})");
                return;
            }
            Task<describeVehicleResponse> vehicleResponse = DecodeVehicleWithVIN(asset);
            vehicleResponse.Wait();
            if (vehicleResponse.Result.VehicleDescription.responseStatus.responseCode == ResponseStatusResponseCode.Unsuccessful)
            {
                vehicleResponse = DecodeVehicleWithYearMakeModel(asset);
                vehicleResponse.Wait();
            }
            //successfull or partial successfull
            if (vehicleResponse.Result.VehicleDescription.responseStatus.responseCode != ResponseStatusResponseCode.Unsuccessful)
                ProcessAllChromeStyle(vehicleResponse, asset);

        }
        internal void DecodeAllAssets(int dealerId)
        {
            List<Asset> assetList = db.GetAssetList(dealerId);
            foreach (var asset in assetList)
            {
                DecodeAssetAndUpdateDB(asset);
            }

        }
        private void DownloadGallaryImages( int styleId)
        {
            List<string> imgUrls = db.GetGalleryImageList(styleId, StockImageType.view);
            string foldername;
            if (db.RunMode == "TEST")
                foldername = @"e:/ezlogs/images/";
            else
                foldername = @"D:/www/WebApplications/AutodataImages/ChromeDataImages/";

            foreach (string url in imgUrls)
            {
                FileDownLoader.WriteBytesToFile(foldername + ExtractImageName(url), FileDownLoader.GetBytesFromUrl(url));
                Logger.Instance.Write($"downloaded view image {url}");
            }
            Logger.Instance.Write($"Style ={styleId} has {imgUrls.Count} view images");
            //
            imgUrls = db.GetGalleryImageList(styleId, StockImageType.colorized);
            foreach (string url in imgUrls)
            {
                FileDownLoader.WriteBytesToFile(foldername + ExtractImageName(url), FileDownLoader.GetBytesFromUrl(url));
                Logger.Instance.Write($"downloaded colorized image {url}");
            }
            Logger.Instance.Write($"Style ={styleId} has {imgUrls.Count} Colorized images");
            //
            string stockUrl = db.GetStockImageUrl(styleId);
            FileDownLoader.WriteBytesToFile(foldername + ExtractImageName(stockUrl), FileDownLoader.GetBytesFromUrl(stockUrl));
            Logger.Instance.Write($"Style ={styleId} has {stockUrl} Stock Image.");
        }
        private void ProcessAllChromeStyle(Task<describeVehicleResponse> x, Asset asset)
        {
            VehicleDescription vd = x.Result.VehicleDescription;
            if (vd == null)
            {
                Logger.Instance.Write($"Vehicle Description is null for VIN={asset.Vin}, Ext color={asset.ExteriorColor}");
                return;
            }
            int sId = 0;
            if (vd.style != null && vd.style[0] != null && vd.style[0].id > 0)
                sId = vd.style[0].id;

            if (sId == 0)
            {
                Logger.Instance.Write($"StyleId not set for VIN={asset.Vin}, Ext color={asset.ExteriorColor}");
                return;
            }
            int StyleIndex = 0;
            if (vd.style.Length == 1)
            {
                Logger.Instance.Write($"ChromeWebService decoded vin = {asset.Vin} to  StyleId = {sId}");
            }
            else
            {
                StyleIndex = EzDecodeVin(asset, vd.style);
                Logger.Instance.Write($"ChromeWebService returned {vd.style.Length} Style Ids for  vin = {asset.Vin}");
            }
            Logger.Instance.Write($"StyleIndex = {StyleIndex}");
            ProcessChromeStyle(asset, vd, StyleIndex);
            db.InsertChromeDecodedAsset(asset);

        }
        private void ProcessChromeStyle(Asset asset, VehicleDescription vd, int StyleIndex)
        {
            int styleId = vd.style[StyleIndex].id;
            string chromeimageId = "";
            if (vd.style[StyleIndex].mediaGallery != null && vd.style[StyleIndex].mediaGallery.view[0] != null)
            {
                chromeimageId = ExtractImageId(vd.style[StyleIndex].mediaGallery.view[0].url);
            }

            asset.ChromeImageId = chromeimageId;
            asset.StyleId = vd.style[StyleIndex].id;
            Color clr = GetExteriorColor(vd.exteriorColor);
            if (clr != null)
            {
                asset.ChromeExtColorOptionCode = clr.colorCode;
                asset.ChromeExtRGBHexCode = clr.rgbValue;
                asset.ChromeExtColorName = clr.colorName;
            }


            asset.ChromeImageUrl = GetColorMatchedImage(vd.style[StyleIndex].mediaGallery, asset.ChromeExtColorOptionCode);
            if (asset.ChromeImageUrl == "") GetDefaultGalleryImage(vd.style[StyleIndex].mediaGallery);

            db.InsertAdsStandardEquipments(asset.AssetId, styleId, GetStandardEquipments(styleId, vd.standard));
            db.InsertAdsGenericEquipments(asset.AssetId, styleId, GetGenericEquipments(styleId, vd.genericEquipment));
            db.InsertAdsTechnicalSpecs(asset.AssetId, styleId, GetTechnicalSpecs(styleId, vd.technicalSpecification));
            db.InsertAdsFactoryOptions(asset.AssetId, styleId, GetFactoryOptions(styleId, vd.factoryOption, vd.exteriorColor));
            db.InsertAdsConsumerInfos(asset.AssetId, styleId, GetConsumerInfos(styleId, vd.consumerInformation));
            db.InsertStyleColors(styleId, GetExteriorInteriorColors(styleId, vd, ColorType.Exterior));
            db.InsertStyleColors(styleId, GetExteriorInteriorColors(styleId, vd, ColorType.Interior));
            db.InsertStyleGenericColors(styleId, GetGenericColors(styleId, vd.genericColor));
            //db.InsertChromeDecodedAsset(asset);

            ChromeCompareStyleIdDecode decoder1 = new ChromeCompareStyleIdDecode(Helper.ChromeConstructAccountInfo, db);
            decoder1.ProcessChromeCompareService(styleId);


            if (db.IsStyleIdInDB(styleId))
            {
                Logger.Instance.Write($"Style ={styleId} exists in the database");
                return;
            }

            int viewCount = 0;
            int colorizedCount = 0;
            viewCount = InsertMediaGalaryViewImages(vd);
            colorizedCount = InsertMediaGalleryColorizedImages(vd);
            InsertChromeStyle(asset, vd, styleId, viewCount, colorizedCount, chromeimageId);
            DownloadGallaryImages(styleId);
        }
        private int EzDecodeVin1(Asset asset, ChromeServiceReference.Style[] style)
        {
            return 0;
        }
        private int EzDecodeVin(Asset asset, ChromeServiceReference.Style[] styles)
        {
            for(int i=0;i< styles.Length;i++)
            {
                if (asset.TransmissionType == "A" && styles[i].name.Contains("Auto")) return i;
                if (asset.TransmissionType == "M" && styles[i].name.Contains("Man")) return i;

            }
            //todo
            return 0; // no match take first in the list.
        }
        private List<StyleGenericColor> GetGenericColors(int styleId, ChromeServiceReference.GenericColor[] genericColor)
        {
            List<StyleGenericColor> colors = new List<StyleGenericColor>();
            foreach (var color in genericColor)
            {
                StyleGenericColor c = new StyleGenericColor
                {
                    StyleId = styleId,
                    ColorName = color.name ?? "",
                    InstalledCause = "",
                    InstalledDetail = ""
                };
                if (color.primarySpecified) c.IsPrimary = color.primary;
                if (color.installed != null)
                {
                    c.InstalledCause = GetInstallationCauseString(color.installed.cause);
                    c.InstalledDetail = color.installed.detail ?? "";
                }
                colors.Add(c);

            }
            return colors;
        }
        private bool StyleIdMatched(int[] ids, int styleId)
        {
            bool matched = false;
            if (ids != null)
            {
                foreach (int id in ids)
                {
                    if (id == styleId)
                    {
                        matched = true;
                        break;
                    }
                }

            }
            else
            {
                matched = true; // not present means matched
            }

            return matched;
        }
        private List<StyleColor> GetExteriorInteriorColors(int styleId, VehicleDescription vd, ColorType colorType)
        {
            List<StyleColor> colors = new List<StyleColor>();
            Color[] xcolors = colorType == ColorType.Exterior ? vd.exteriorColor : vd.interiorColor;
            foreach (var color in xcolors)
            {
                if (!StyleIdMatched(color.styleId,styleId)) continue;

                StyleColor c = new StyleColor
                {
                    StyleId = styleId,
                    ExteriorInterior = colorType == ColorType.Exterior ? "E":"I",
                    ColorCode = color.colorCode ?? "",
                    ColorName = color.colorName ?? "",
                    RGBHexCode = color.rgbValue ?? "",
                    InstalledCause = "",
                    InstalledDetail = ""
                };
                if (color.installed != null)
                {
                    c.InstalledCause = GetInstallationCauseString(color.installed.cause);
                    c.InstalledDetail = color.installed.detail ?? "";
                }
                colors.Add(c);

            }
            return colors;
        }
        private Color GetExteriorColor(Color[] exteriorColor)
        {
            foreach( Color c in exteriorColor)
            {
                bool matched = false;
                foreach(int sid in c.styleId)
                {
                    matched = true;
                    break;
                }
                if (!matched) continue;
                if (c.installed != null) return c;
            }
            return null;
        }
        private List<AdsFactoryOption> GetFactoryOptions(int styleId, ChromeServiceReference.Option[] options, Color[] exColors)
        {
            List<AdsFactoryOption> fOptions = new List<AdsFactoryOption>();
            foreach (var option in options)
            {
                if (!StyleIdMatched(option.styleId, styleId)) continue;
                string desc = "";
                foreach (string s in option.description) desc += s;
                AdsFactoryOption fo = new AdsFactoryOption
                {
                    StyleId = styleId,
                    HeaderId = 0,
                    HeaderName = "",
                    UTF = option.utf ?? "",
                    Description = desc,
                    ChromeCode = "",
                    OEMCode = "",
                    InstalledCause = "",
                    InstalledDetail = ""

                };
                if (option.header != null)
                {
                    fo.HeaderId = option.header.id;
                    fo.HeaderName = option.header.Value ?? "";
                }
                if (option.price.msrpMaxSpecified) fo.Price = option.price.msrpMax;
                if (option.chromeCode != null) fo.ChromeCode = option.chromeCode;
                if (option.oemCode != null) fo.OEMCode = option.oemCode;
                if (option.installed != null)
                {
                    fo.InstalledCause = GetInstallationCauseString(option.installed.cause);
                    fo.InstalledDetail = option.installed.detail ?? "";
                }
                if (option.standardSpecified) fo.IsStandard = option.standard;
                if (option.fleetOnlySpecified) fo.IsFleetOnly = option.fleetOnly;
                if (option.optionKindIdSpecified)
                {
                    fo.OptionKindId = option.optionKindId;
                    if (fo.OptionKindId == 68) // paint type 
                    {
                        fo.RGBHexCode = GetPaintHexCode(styleId, fo.OEMCode, exColors);
                    }
                }
                fOptions.Add(fo);
            }
            return fOptions;
        }
        private string GetPaintHexCode(int styleId, string colorCode, Color[] colors)
        {

            foreach(var color in colors)
            {
                if (color.colorCode == colorCode)
                {   foreach(int sid in color.styleId)
                    {
                        if (sid == styleId)
                        {
                            return color.rgbValue;
                        }

                    }
                }
            }
            return null;
        }
        private List<AdsConsumerInfo> GetConsumerInfos(int styleId, ChromeServiceReference.ConsumerInformation[] consumerInformations)
        {
            List<AdsConsumerInfo> consumerInfos = new List<AdsConsumerInfo>();
            foreach (var cis in consumerInformations)
            {
                foreach(var itm in cis.item)
                {
                    if (!StyleIdMatched(cis.styleId, styleId)) continue;

                    AdsConsumerInfo ci = new AdsConsumerInfo
                    {
                        StyleId = styleId,
                        HeaderId = 0,
                        HeaderName = "",
                        ItemName = itm.name ?? "",
                        ItemValue = itm.value ?? ""
                    };
                    if (cis.type != null)
                    {
                        ci.HeaderId = cis.type.id;
                        ci.HeaderName = cis.type.Value;
                    }
                    consumerInfos.Add(ci);
                }
            }
            return consumerInfos;
        }
        private List<AdsStandardEquipment> GetStandardEquipments(int styleId, ChromeServiceReference.Standard[] standards)
        {
            List<AdsStandardEquipment> options = new List<AdsStandardEquipment>();
            foreach( var s in standards)
            {
                if (!StyleIdMatched(s.styleId, styleId)) continue;

                AdsStandardEquipment se = new AdsStandardEquipment
                {
                    StyleId = styleId,
                    Description = s.description ?? "",
                    Header = s.header != null ? s.header.Value : "",
                    InstalledCause = s.installed != null ?  GetInstallationCauseString(s.installed.cause) : "",
                    InstalledDetail = s.installed != null ? s.installed.detail ?? "" : "",
                    AdsStandardEquipmentCategories = new List<int>()
                };
                if (s.category != null)
                {
                    foreach (CategoryAssociation c in s.category)  se.AdsStandardEquipmentCategories.Add(c.id);
                }
                options.Add(se);

            }
            return options;
        }
        private List<AdsTechnicalSpec> GetTechnicalSpecs(int styleId, ChromeServiceReference.TechnicalSpecification[] technicalSpecifications)
        {
            List<AdsTechnicalSpec> techSpecs = new List<AdsTechnicalSpec>();
            foreach (var ts in technicalSpecifications)
            {
                foreach (var val in ts.value)
                {
                    if (StyleIdMatched(val.styleId, styleId)) 
                    {
                        AdsTechnicalSpec techSpec = new AdsTechnicalSpec()
                        {
                            StyleId = styleId,
                            TitleId = ts.Item != null ? (int)ts.Item : 0,
                            Condition = val.condition ?? "",
                            Value = val.value ?? ""
                        };
                        if (ts.range != null) techSpec.RangeMin = ts.range.min;
                        if (ts.range != null) techSpec.RangeMax = ts.range.max;
                        techSpecs.Add(techSpec);
                    }
                }
            }
            return techSpecs;
        }
        private List<AdsGenericEquipment> GetGenericEquipments(int styleId, ChromeServiceReference.GenericEquipment[] genericEquipments)
        {
            List<AdsGenericEquipment> ges = new List<AdsGenericEquipment>();
            foreach (var ge in genericEquipments)
            {
                foreach (int sid in ge.styleId)
                {
                    if (StyleIdMatched(ge.styleId, styleId)) 
                    {
                        AdsGenericEquipment g = new AdsGenericEquipment()
                        {
                            StyleId = styleId,
                            CategoryId = (int)ge.Item,
                        };
                        if (ge.installed != null)
                        {
                            g.InstalledCause = GetInstallationCauseString(ge.installed.cause);
                            g.InstalledDetail = ge.installed.detail ?? "";
                        }
                        else
                        {
                            g.InstalledCause = "";
                            g.InstalledDetail = "";
                        }
                        ges.Add(g);
                    }
                }
            }
            return ges;
        }
        private string GetInstallationCauseString(ChromeServiceReference.InstallationCauseCause installedCause)
        {
            switch(installedCause)
            {
                case InstallationCauseCause.Engine:
                    return "EN";
                case InstallationCauseCause.RelatedCategory:
                    return "RT";
                case InstallationCauseCause.RelatedColor:
                    return "RC";
                case InstallationCauseCause.CategoryLogic:
                    return "CL";
                case InstallationCauseCause.PrimaryOptionNameInput:
                    return "PI";
                case InstallationCauseCause.OptionLogic:
                    return "OL";
                case InstallationCauseCause.OptionCodeBuild:
                    return "OB";
                case InstallationCauseCause.ExteriorColorBuild:
                    return "XB";
                case InstallationCauseCause.InteriorColorBuild:
                    return "IB";
                case InstallationCauseCause.EquipmentDescriptionInput:
                    return "EI";
                case InstallationCauseCause.ExteriorColorInput:
                    return "XI";
                case InstallationCauseCause.InteriorColorInput:
                    return "II";
                case InstallationCauseCause.OptionCodeInput:
                    return "OI";
                case InstallationCauseCause.BaseEquipment:
                    return "BE";
                case InstallationCauseCause.VIN:
                    return "VN";
                case InstallationCauseCause.NonFactoryEquipmentInput:
                    return "NI";
                default:
                    return "";
            }
        }
        private string GetColorMatchedImage(MediaGallery mediaGallery, string colorCode )
        {
            string retval = "";
            if (mediaGallery != null && mediaGallery.colorized != null)
            {
                foreach (var img in mediaGallery.colorized)
                {
                    if (img.match &&
                        img.shotCode == "01" &&
                        img.backgroundDescription == "White" &&
                        img.primaryColorOptionCode == colorCode &&
                        img.width == 640)
                    {
                        retval = img.url;
                        break;
                    }
                }
            }
            return retval;
        }
        private string GetDefaultGalleryImage(MediaGallery mediaGallery)
        {
            string retval = "";
            if (mediaGallery != null && mediaGallery.view != null)
            {
                foreach (var img in mediaGallery.view)
                {
                    if (img.shotCode == "01" &&
                        img.backgroundDescription == "White" &&
                        img.width == 640)
                    {
                        retval = img.url;
                        break;
                    }
                }
            }
            return retval;
        }
        private void InsertChromeStyle(Asset asset, VehicleDescription vd, int styleId, int viewCount, int colorizedCount, string chromeimageId)
        {
            ChromeStyle s = new ChromeStyle
            {
                StyleId = styleId,
                StyleName = vd.style[0].name ?? "",
                ChromeImageID = chromeimageId ??"",
                StockImage = vd.style[0].stockImage.url ?? "",
                Acode = vd.style[0].acode[0].Value ?? "",
                BestMakeName = vd.bestMakeName ?? "",
                BestTrimName = vd.bestTrimName ?? "",
                BestStyleName = vd.bestStyleName ?? "",
                BestModelName = vd.bestModelName ?? "",
                ViewImageCount = viewCount,
                ColorizedImageCount = colorizedCount
            };
            if (vd.vinDescription != null)
            {
                if (vd.vinDescription.vin != null) s.VIN = vd.vinDescription.vin;
                if (vd.vinDescription.division != null) s.MakeName = vd.vinDescription.division;
                if (vd.vinDescription.modelYear != 0) s.ModelYear = vd.vinDescription.modelYear;
                if (vd.vinDescription.modelName != null) s.ModelName = vd.vinDescription.modelName;
                if (vd.vinDescription.bodyType != null) s.BodyType = vd.vinDescription.bodyType;
                if (vd.vinDescription.WorldManufacturerIdentifier != null) s.WorldManufacturer = vd.vinDescription.WorldManufacturerIdentifier;

            }

            if (vd.engine != null && vd.engine[0] != null)
            {
                s.Cylinders = vd.engine[0].cylinders > -1 ? vd.engine[0].cylinders : 0;
                s.FuelType = vd.engine[0].fuelType.Value;
                s.Engine = vd.engine[0].engineType.Value;
                if (vd.engine[0].displacement != null &&
                    vd.engine[0].displacement[0] != null &&
                    vd.engine[0].displacement[0].unit != null
                   )
                    s.Displacement = vd.engine[0].displacement[0].Value + " " + vd.engine[0].displacement[0].unit;

            }

            db.InsertChromeStyle(s, asset.DealerId);
        }
        private int InsertMediaGalleryColorizedImages(VehicleDescription vd)
        {
            if (vd.style[0].mediaGallery == null) return 0;
            if (vd.style[0].mediaGallery.colorized == null) return 0;
            var colorizedImages = vd.style[0].mediaGallery.colorized;
            int count = 0;
            foreach (MediaGalleryColorized c in colorizedImages)
            {
                GalleryImage img = new GalleryImage
                {
                    ImageType = "C",
                    StyleId = vd.style[0].id,
                    ShotCode = c.shotCode,
                    BackgroundDescription = c.backgroundDescription,
                    Url = c.url,
                    Width = c.width,
                    Height = c.height,
                    PrimaryColorOptionCode = c.primaryColorOptionCode,
                    PrimaryRGBHexCode = c.primaryRGBHexCode
                };
                db.InsertChromeImageDetails(img);
                count++;
            }
            return count;
        }
        private int InsertMediaGalaryViewImages(VehicleDescription vd)
        {
            if (vd.style[0].mediaGallery == null) return 0;
            if (vd.style[0].mediaGallery.view == null) return 0;

            var viewImages = vd.style[0].mediaGallery.view;
            int count = 0;
            foreach (MediaGalleryView v in viewImages)
            {
                GalleryImage img = new GalleryImage
                {
                    ImageType = "V",
                    StyleId = vd.style[0].id,
                    ShotCode = v.shotCode,
                    BackgroundDescription = v.backgroundDescription,
                    Url = v.url,
                    Width = v.width,
                    Height = v.height
                };
                db.InsertChromeImageDetails(img);
                count++;
            }
            return count;

        }
        private string ExtractImageId(string url)
        {
            string imgname = ExtractImageName(url);
            string ret = imgname.Split("_")[0];
            if (ret == null) return "";
            return ret;

        }
        private string ExtractImageName(string url)
        {
            int position = url.LastIndexOf('/');
            if (position == -1) return "";
            return url.Substring(position + 1);
        }
        private async Task<describeVehicleResponse> DecodeVehicleWithVIN(Asset asset)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            VehicleDescriptionRequest req = new VehicleDescriptionRequest
            {
                 accountInfo = accountInfo
            };

            Object[] itms = new object[1];
            req.Items = itms;
            ItemsChoiceType[] itmname = new ItemsChoiceType[1];

            req.ItemsElementName = itmname;
            req.ItemsElementName[0] = ChromeServiceReference.ItemsChoiceType.vin;
            req.Items[0] = (object)asset.Vin;
            req.includeMediaGallery = ChromeServiceReference.SwitchChromeMediaGallery.Both;
            req.includeMediaGallerySpecified = true;
            Switch[] sw = new Switch[4];
            sw[0] = Switch.ShowAvailableEquipment;
            sw[1] = Switch.ShowExtendedTechnicalSpecifications;
            sw[2] = Switch.ShowConsumerInformation;
            sw[3] = Switch.ShowExtendedDescriptions;

            req.@switch = sw;

            if (asset.ExteriorColor != "") req.exteriorColorName = asset.ExteriorColor;
            if (asset.Trim != "") req.trimName = asset.Trim;
            describeVehicleResponse result = await client.describeVehicleAsync(req);
            return result;

        }
        private async Task<describeVehicleResponse> DecodeVehicleWithYearMakeModel(Asset asset)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            VehicleDescriptionRequest req = new VehicleDescriptionRequest
            {
                    accountInfo = accountInfo
            };

            Object[] itms = new object[3];
            req.Items = itms;
            ItemsChoiceType[] itmname = new ItemsChoiceType[3];
            req.ItemsElementName = itmname;
            req.ItemsElementName[0] = ChromeServiceReference.ItemsChoiceType.modelYear;
            req.Items[0] = (object)asset.Year;
            req.ItemsElementName[1] = ChromeServiceReference.ItemsChoiceType.makeName;
            req.Items[1] = (object)asset.Make;
            req.ItemsElementName[2] = ChromeServiceReference.ItemsChoiceType.modelName;
            req.Items[2] = (object)asset.Model;
            req.includeMediaGallery = ChromeServiceReference.SwitchChromeMediaGallery.Both;
            req.includeMediaGallerySpecified = true;
            if (asset.ExteriorColor != "") req.exteriorColorName = asset.ExteriorColor;

            describeVehicleResponse result = await client.describeVehicleAsync(req);
            return result;

        }
    }
}