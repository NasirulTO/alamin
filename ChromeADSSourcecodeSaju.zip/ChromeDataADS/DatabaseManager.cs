﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using ChromeCompareServiceReference;
using Dapper;
namespace ChromeDataADS
{
    public class DatabaseManager
    {
        //static String ConnString = "Pooling=false;Data Source=192.168.100.136;Initial Catalog=ezDB;Persist Security Info=True;User ID=UAPremium;Password=jUIH237DheE89";
        readonly string ConnString;
        public string RunMode { get; private set; }
        public DatabaseManager(string opt, string userid, string pwd)
        {
            // TODO
            ConnString = "Enter yor connection string here";
            RunMode = "DEV";
            Console.WriteLine("DEV DB configured");
            //
            if (opt == "LIVE")
            {
                ConnString = $"Pooling=false;Data Source=192.168.100.136;Initial Catalog=ezDB;Persist Security Info=True;User ID={userid};Password={pwd}";
                RunMode = "LIVE";
                Console.WriteLine("Live DB configured");
            }
            else if (opt == "EZTEST")
            {
                ConnString = "Integrated Security=true;server=(local);Initial Catalog=ezDB;";
                RunMode = "EZTEST";
                Console.WriteLine("EZ Test DB configured");
            }


        }

        public void UpdateAsset(Asset asset)
        {
            const string updateSQL = @"update tbl_Assets 
                                        set StyleId = @StyleId,
                                            ChromeColorOptionCode = @ChromeColorOptionCode,
                                            ChromeRGBHexCode = @ChromeRGBHexCode,
                                            ChromeImageId = @ChromeImageId,
                                            ChromeColorName = @ChromeColorName
                                        where Asset_Id = @AssetId";
            
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlCommand sqlCommand = new SqlCommand(updateSQL, sqlConnection))
                {
                    try
                    {
                        SqlParameter paramStyleId = new SqlParameter("@StyleId", asset.StyleId);
                        sqlCommand.Parameters.Add(paramStyleId);
                        SqlParameter paramChromeColorOptionCode = new SqlParameter("@ChromeColorOptionCode", asset.ChromeExtColorOptionCode);
                        sqlCommand.Parameters.Add(paramChromeColorOptionCode);
                        SqlParameter paramChromeRGBHexCode = new SqlParameter("@ChromeRGBHexCode", asset.ChromeExtRGBHexCode);
                        sqlCommand.Parameters.Add(paramChromeRGBHexCode);
                        SqlParameter paramChromeImageId = new SqlParameter("@ChromeImageId", asset.ChromeImageId);
                        sqlCommand.Parameters.Add(paramChromeImageId);
                        SqlParameter paramChromeColorName = new SqlParameter("@ChromeColorName", asset.ChromeExtColorName);
                        sqlCommand.Parameters.Add(paramChromeColorName);
                        SqlParameter paramAssetId = new SqlParameter("@AssetId", asset.AssetId);
                        sqlCommand.Parameters.Add(paramAssetId);
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write("  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                    }
                }
            }
        }
        public bool IsStyleIdInDB(int styleId)
        {

            bool retval = true;
            const string SelectSQL = @"
                            select styleId from ChromeDecodedStyles where StyleId = @StyleId";

            using (SqlConnection conn = new SqlConnection(ConnString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(SelectSQL, conn))
                {
                    conn.Open();
                    SqlParameter paramStyleId = new SqlParameter("@StyleId",styleId);
                    sqlCommand.Parameters.Add(paramStyleId);
                    try
                    {
                        object o = sqlCommand.ExecuteScalar();
                        if (o == null) {
                            retval = false;
                        }
                        else
                        {
                            retval = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        retval = true; // to avoid duplicates
                    }
                }
            }
            return retval;
        }
        public bool IsVINDecoded(int styleId)
        {

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                int x = sqlConnection.QuerySingleOrDefault<int>("select styleId from tbl_assets where StyleId = @styleId", new { styleId });
                if (x > 0) return true;
            }
            return false;
        }

        public string GetStockImageUrl(int styleId)
        {

            const string selectSQL = @"select isnull(StockImage,'') from ChromeDecodedStyles where StyleId = @StyleId";
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                return sqlConnection.QuerySingleOrDefault<string>(selectSQL, new { styleId });
            }
        }

        public List<string> GetGalleryImageList(int styleId, StockImageType stockImageType)
        {
            var imgUrlList = new List<string>();
            if (stockImageType == StockImageType.Unknown) return imgUrlList;

            //const string selectSQL = @"select Url from ChromeImages where styleId=@StyleId and imageType=@ImageType 
            //                           and BackgroundDescription = 'Transparent' and width = 640;";
            string selectSQL = @"select Url from ChromeImages where styleId=@StyleId and imageType=@ImageType 
                                       and BackgroundDescription = 'White' and width = 640;";

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                imgUrlList = sqlConnection.Query<string>(selectSQL, 
                            new
                                {
                                    StyleId = styleId,
                                    ImageType = stockImageType == StockImageType.view ? "V" : "C"
                                }).AsList<string>();
            }
            return imgUrlList;

        }
        public List<Asset> GetAssetList(int dealerId, List<int> idList)
        {

            var assetList = new List<Asset>();
            if (dealerId < 1) return assetList;
            if (idList.Count < 1) return assetList; //emptylist

            string selectSQL = @"
                select 
                AssetId = a.Asset_Id, 
                ModelYear = isnull(a.Model_Year,0), 
                MakeName =isnull(a.Make_Name,''), 
                ModelName = isnull(a.Model_Name,''),
                DealerId = Dealer_Id, 
                Vin = isnull(a.Vin, ''), 
                Ext_Color = isNull(Ext_Color, ''),
                Trim = isNull(Series_Name, ''),
                StyleId = isNull(c.Styleid, 0)
                from tbl_assets a left join 
                ChromeDecodedAssets c on a.Asset_Id = c.AssetId
                where deleted = 0 and dealer_id = @DealerId
                and a.asset_Id in @Ids";

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                assetList = sqlConnection.Query<Asset>(selectSQL,
                            new
                            {
                                DealerId = dealerId,
                                Ids = idList

                            }).AsList<Asset>();
            }
            return assetList;
        }
        public List<Asset> GetAssetList(int dealerId)
        {

            var assetList = new List<Asset>();
            if (dealerId < 1) return assetList;

            string selectSQL = @"
                select
                AssetId = a.Asset_Id, 
                ModelYear = isnull(a.Model_Year,0), 
                MakeName =isnull(a.Make_Name,''), 
                ModelName = isnull(a.Model_Name,''),
                DealerId = Dealer_Id, 
				TransmissionType = isnull(a.Transmission_type,''),
                Vin = isnull(a.Vin, ''), 
                Ext_Color = isNull(Ext_Color, ''),
                Trim = isNull(Series_Name, ''),
                StyleId = isNull(c.Styleid, 0)
                from tbl_assets a left join 
                ChromeDecodedAssets c on a.Asset_Id = c.Asset_Id
                where deleted = 0 and dealer_id = @DealerId and a.vin is not null order by 1 desc";

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                assetList = sqlConnection.Query<Asset>(selectSQL,
                            new
                            {
                                DealerId = dealerId
 
                            }).AsList<Asset>();
            }
            return assetList;
        }

        public void InsertChromeDecodedAsset(Asset asset)
        {
            const string insertSQL = @"insert into ChromeDecodedAssets 
                                        ( Asset_Id, Vin, StyleId, ColorOptionCode, RGBHexCode, 
                                          ChromeExtColorName, ChromeImageUrl, ChromeImageId)
                                        values
                                        ( @AssetId, @Vin, @StyleId, @ChromeExtColorOptionCode, @ChromeExtRGBHexCode, 
                                          @ChromeExtColorName, @ChromeImageUrl, @ChromeImageId )";

            if (asset == null) return;

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(insertSQL, asset, sqlTrans);
                        sqlTrans.Commit();
                        Logger.Instance.Write($"Inserted ChromeDecodedAssets for AssetId={asset.AssetId},StyleId={asset.StyleId}");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeDecodedAssets for styleId = {asset.StyleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertChromeImageDetails(GalleryImage galleryImage)
        {
            const string insertSQL = @"
                insert into ChromeImages(
                    ImageType,  StyleId, Url, ShotCode, BackgroundDescription, Width, Height, 
                    PrimaryColorOptionCode, PrimaryRGBHexCode
                ) values(
                    @ImageType, @StyleId, @Url, @ShotCode, @BackgroundDescription, @Width, @Height,
                    @PrimaryColorOptionCode, @PrimaryRGBHexCode
                )";

            const string deleteSQL = @"delete from ChromeImages where StyleId = @StyleId";

            if (galleryImage == null) return;

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new {styleId = galleryImage.StyleId}, sqlTrans);
                        sqlConnection.Execute(insertSQL, galleryImage, sqlTrans);
                        sqlTrans.Commit();
                        Logger.Instance.Write($"Inserted ChromeImages for {galleryImage.StyleId}, Type={galleryImage.ImageType.ToString()}");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeImages for styleId = {galleryImage.StyleId} rollbacked with error: {ex.Message}");
                    }
                }
            }
        }
        public void InsertAdsStandardEquipments(int assetId, int styleId, List<AdsStandardEquipment> options)
        {
            const string insertSQL1 = @"insert into ChromeADSStandardEquipments 
                                        (StyleId, Header, InstalledCause, InstalledDetail, Description) values 
                                        (@StyleId, @Header, @InstalledCause, @InstalledDetail, @Description);
                                        SET @NewId = SCOPE_IDENTITY()";
            const string insertSQL2 = @"insert into ChromeADSStandardEquipmentCatagories values 
                                        (@StandardEquipmentId, @CategoryId, @StyleId)";

            const string deleteSQL1 = @"delete from ChromeADSStandardEquipments where StyleId = @StyleId";
            const string deleteSQL2 = @"delete from ChromeADSStandardEquipmentCatagories where StyleId = @StyleId";

            if (styleId == 0 || options.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL1, new { styleId }, sqlTrans);
                        sqlConnection.Execute(deleteSQL2, new { styleId }, sqlTrans);
                        foreach (AdsStandardEquipment opt in options)
                        {
                            var p = new DynamicParameters();
                            p.Add("StyleId", opt.StyleId);
                            p.Add("Header", opt.Header);
                            p.Add("InstalledCause", opt.InstalledCause);
                            p.Add("InstalledDetail", opt.InstalledDetail);
                            p.Add("Description", opt.Description);
                            p.Add("NewId", dbType: DbType.Int32, direction: ParameterDirection.Output);
                            sqlConnection.Query<int>(insertSQL1, p, sqlTrans);
                            string  newId = p.Get<int>("NewId").ToString(); ;
                            Logger.Instance.Write($"std opt = {opt.Description} inserted");
                            foreach (int catId in opt.AdsStandardEquipmentCategories)
                            {
                                sqlConnection.Execute(insertSQL2, new { StandardEquipmentId = newId, CategoryId= catId, styleId= opt.StyleId }, sqlTrans);
                                Logger.Instance.Write($"std opt Equipment( Id = {newId}, CatId={catId}) inserted");
                            }
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeADSStandardEquipments/ChromeADSStandardEquipmentCatagories for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertAdsTechnicalSpecs(int assetId, int styleId, List<AdsTechnicalSpec> specs)
        {
            const string insertSQL = @"insert into ChromeAdsTechnicalSpecs 
                                        (StyleId, TitleId, RangeMin, RangeMax, Value, Condition) values 
                                        (@StyleId, @TitleId, @RangeMin, @RangeMax, @Value, @Condition)";

            const string deleteSQL = @"delete from ChromeAdsTechnicalSpecs where StyleId = @StyleId";

            if (assetId == 0 || specs.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (AdsTechnicalSpec spec in specs)
                        {

                            sqlConnection.Execute(insertSQL, spec, sqlTrans);
                            Logger.Instance.Write($"tech spec = {spec.Value} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeAdsTechnicalSpecs for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertAdsConsumerInfos(int assetId, int styleId, List<AdsConsumerInfo> consumerInfos)
        {
            const string insertSQL = @"insert into ChromeAdsConsumerInformations 
                                        (StyleId, HeaderId, HeaderName, ItemName, ItemValue) values 
                                        (@StyleId, @HeaderId, @HeaderName, @ItemName, @ItemValue)";

            const string deleteSQL = @"delete from ChromeAdsConsumerInformations where StyleId=@StyleId";

            if (assetId == 0 || consumerInfos.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (AdsConsumerInfo consumerInfo in consumerInfos)
                        {
                            sqlConnection.Execute(insertSQL, consumerInfo, sqlTrans);
                            Logger.Instance.Write($"Consumer Info = {consumerInfo.ItemName} = {consumerInfo.ItemValue} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeAdsConsumerInformations for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertAdsGenericEquipments(int assetId, int styleId, List<AdsGenericEquipment> genericEquipments)
        {
            const string insertSQL = @"insert into ChromeAdsGenericEquipments 
                                        (StyleId, CategoryId, InstalledCause, InstalledDetail) values 
                                        (@StyleId, @CategoryId, @InstalledCause, @InstalledDetail)";

            const string deleteSQL = @"delete from ChromeAdsGenericEquipments where StyleId = @StyleId";

            if (assetId == 0 || genericEquipments.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (AdsGenericEquipment genericEquipment in genericEquipments)
                        {
                            sqlConnection.Execute(insertSQL, genericEquipment, sqlTrans);
                            Logger.Instance.Write($"Generic Equipment = {genericEquipment.CategoryId} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write($"For Asset Id= {assetId},  Generic Equipment  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeAdsGenericEquipments for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertAdsFactoryOptions(int assetId, int styleId, List<AdsFactoryOption> factoryOptions)
        {
            const string insertSQL = @"insert into ChromeAdsFactoryOptions 
                                       (StyleId, HeaderId, HeaderName, Description, Price, InstalledCause, InstalledDetail, ChromeCode, OemCode, 
                                         IsStandard, OptionKindId,UTF, RGBHexCode, IsFleetOnly ) values 
                                       (@StyleId, @HeaderId, @HeaderName, @Description, @Price, @InstalledCause, @InstalledDetail, @ChromeCode, @OemCode, 
                                         @IsStandard, @OptionKindId, @UTF, @RGBHexCode, @IsFleetOnly )";

            const string deleteSQL = @"delete from ChromeAdsFactoryOptions where StyleId=@StyleId";

            if (assetId == 0 || factoryOptions.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (AdsFactoryOption opt in factoryOptions)
                        {
                            Logger.Instance.Write($"Inserting factory option = {opt.Description}");
                            sqlConnection.Execute(insertSQL, opt, sqlTrans);

                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeAdsFactoryOptions for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        //
        public void InsertTechnicalSpecs(int styleId, List<TechnicalSpecification> specs)
        {
            const string insertSQL = @"
                insert into ChromeTechnicalSpecs 
                (StyleId, GroupId, GroupName, HeaderId, HeaderName, 
                 TitleId, TitleName, Value, Unit, UpGrade, Sequence) 
                 Values
                (@StyleId, @GroupId, @GroupName, @HeaderId, @HeaderName, 
                 @TitleId, @TitleName, @Value, @Unit, @UpGrade, @Sequence)";

            const string deleteSQL = @"delete from ChromeTechnicalSpecs where StyleId = @StyleId";

            if (styleId == 0 || specs.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (TechnicalSpecification spec in specs)
                        {
                            sqlConnection.Execute(insertSQL, spec, sqlTrans);
                            Logger.Instance.Write($"ChromeTechnicalSpecs( {spec.TitleName} inserted)");

                        }
                        sqlTrans.Commit();
                        Logger.Instance.Write($"For Style Id= {styleId}, ChromeTechnicalSpecs transaction commited)");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeTechnicalSpecs for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertConsumerInfo(int styleId, List<ConsumerInfo> consumerInfos)
        {
            const string insertSQL = @"insert into ChromeConsumerInformations
                                      (StyleId, TypeName, ItemName, ItemValue, ConditionNote, Sequence) values 
                                      (@StyleId, @TypeName, @ItemName, @ItemValue, @ConditionNote, @Sequence)";

            const string deleteSQL = @"delete from ChromeConsumerInformations where StyleId = @StyleId";

            if (styleId == 0 || consumerInfos.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (ConsumerInfo consumerInfo in consumerInfos)
                        {
                            sqlConnection.Execute(insertSQL, consumerInfo, sqlTrans);
                            Logger.Instance.Write($"ChromeConsumerInformations ({consumerInfo.ItemName} = {consumerInfo.ItemValue}) inserted");
                        }
                        sqlTrans.Commit();
                        Logger.Instance.Write($"ChromeConsumerInformations for StyleId = {styleId} commited");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeConsumerInformations for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertOptions(int styleId, Option[] options)
        {
            const string insertSQL = @"insert into ChromeStyleOptions 
                (StyleId, HeaderId,	HeaderName, ConsumerFriendlyHeaderId, ConsumerFriendlyHeaderName,
                 CustomEquipment, AffectingOptionCode, ChromeOptionCode, Description, ExtendedEquipment,
	             FrontWeight, Invoice, Msrp, OemOptionCode,	OptionFamilyCode, 	OptionFamilyName,
	             OptionKindId, OptionPackage, OptionPackageContentOnly,	 RearWeight, RgbValue, SelectionState,
                 SpecialEquipment, UniqueTypeFilter
	            ) values
                (@StyleId, @HeaderId, @HeaderName, @ConsumerFriendlyHeaderId, @ConsumerFriendlyHeaderName,
                 @CustomEquipment, @AffectingOptionCode, @ChromeOptionCode, @Description, @ExtendedEquipment,
	             @FrontWeight, @Invoice, @Msrp, @OemOptionCode,	@OptionFamilyCode, @OptionFamilyName,
	             @OptionKindId, @OptionPackage, @OptionPackageContentOnly, @RearWeight, @RgbValue, @SelectionState,
                 @SpecialEquipment, @UniqueTypeFilter)
                 SET @NewId = SCOPE_IDENTITY()";

            const string deleteSQL1 = "delete from ChromeStyleOptions where StyleId = @StyleId";
            const string deleteSQL2 = "delete from ChromeStyleOptionCatagories where StyleId = @StyleId";

            if (styleId == 0 || options.Length == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    SqlCommand sqlCommand;
                    try
                    {
                        sqlConnection.Execute(deleteSQL1, new { styleId }, sqlTrans);
                        sqlConnection.Execute(deleteSQL2, new { styleId }, sqlTrans);
                        foreach (Option opt in options)
                        {
                            sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            sqlCommand.Parameters.Add(new SqlParameter("@StyleId", styleId));
                            sqlCommand.Parameters.Add(new SqlParameter("@HeaderId", opt.headerId));
                            sqlCommand.Parameters.Add(new SqlParameter("@HeaderName", opt.headerName));
                            sqlCommand.Parameters.Add(new SqlParameter("@ConsumerFriendlyHeaderId", (object)opt.consumerFriendlyHeaderId ?? DBNull.Value));
                            sqlCommand.Parameters.Add(new SqlParameter("@ConsumerFriendlyHeaderName", opt.consumerFriendlyHeaderName));
                            sqlCommand.Parameters.Add(new SqlParameter("@CustomEquipment", opt.customEquipment));
                            sqlCommand.Parameters.Add(new SqlParameter("@AffectingOptionCode", opt.affectingOptionCode));
                            sqlCommand.Parameters.Add(new SqlParameter("@ChromeOptionCode", opt.chromeOptionCode));
                            sqlCommand.Parameters.Add(new SqlParameter("@Description", GetPrimaryDesciption(opt.descriptions)));
                            sqlCommand.Parameters.Add(new SqlParameter("@ExtendedEquipment", opt.extendedEquipment));
                            sqlCommand.Parameters.Add(new SqlParameter("@FrontWeight", opt.frontWeight));
                            sqlCommand.Parameters.Add(new SqlParameter("@Invoice", opt.invoice));
                            sqlCommand.Parameters.Add(new SqlParameter("@Msrp", opt.msrp));
                            sqlCommand.Parameters.Add(new SqlParameter("@OemOptionCode", opt.oemOptionCode));
                            sqlCommand.Parameters.Add(new SqlParameter("@OptionFamilyCode", opt.optionFamilyCode));
                            sqlCommand.Parameters.Add(new SqlParameter("@OptionFamilyName", opt.optionFamilyName));
                            sqlCommand.Parameters.Add(new SqlParameter("@OptionKindId", opt.optionKindId));
                            sqlCommand.Parameters.Add(new SqlParameter("@OptionPackage", opt.optionPackage));
                            sqlCommand.Parameters.Add(new SqlParameter("@OptionPackageContentOnly", opt.optionPackageContentOnly));
                            sqlCommand.Parameters.Add(new SqlParameter("@RearWeight", opt.rearWeight));
                            sqlCommand.Parameters.Add(new SqlParameter("@RgbValue", (object)opt.rgbValue ?? DBNull.Value));
                            sqlCommand.Parameters.Add(new SqlParameter("@SelectionState", opt.selectionState.ToString()));
                            sqlCommand.Parameters.Add(new SqlParameter("@SpecialEquipment", opt.specialEquipment));
                            sqlCommand.Parameters.Add(new SqlParameter("@UniqueTypeFilter", opt.uniqueTypeFilter));
                            SqlParameter returnId = new SqlParameter("@NewId", System.Data.SqlDbType.Int)
                            {
                                Direction = System.Data.ParameterDirection.Output
                            };
                            sqlCommand.Parameters.Add(returnId);
                            Logger.Instance.Write($"Inserting ChromeStyleOptions( {opt.consumerFriendlyHeaderName})");
                            sqlCommand.ExecuteNonQuery();

                            string newId = "" + sqlCommand.Parameters["@NewId"].Value;
                            if (opt.categories != null)
                            {
                                foreach (Category c in opt.categories)
                                {
                                    sqlCommand = new SqlCommand(@"
                                        insert into ChromeStyleOptionCatagories 
                                        (OptionId, CategoryId, CategoryFlag, StyleId ) values 
                                        (@OptionId, @CategoryId, @CategoryFlag, @StyleId )", sqlConnection, sqlTrans);

                                    sqlCommand.Parameters.Add(new SqlParameter("@OptionId", newId));
                                    sqlCommand.Parameters.Add(new SqlParameter("@CategoryId", c.categoryId));
                                    sqlCommand.Parameters.Add(new SqlParameter("@CategoryFlag", (object)c.categoryFlag.ToString() ?? DBNull.Value));
                                    sqlCommand.Parameters.Add(new SqlParameter("@StyleId", styleId));
                                    Logger.Instance.Write($"Inserting ChromeStyleOptionCatagories( Id = {newId}, CatId={c.categoryId})");
                                    sqlCommand.ExecuteNonQuery();
                                }
                            }
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeStyleOptions / ChromeStyleOptionCatagories for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertStandardEquipments(int styleId, List<StandardEquipment> equipments)
        {
            const string insertSQL = @"insert into ChromeStandardEquipments 
                  (StyleId, HeaderId, HeaderName, ConsumerFriendlyHeaderId, ConsumerFriendlyHeaderName, 
                   Description, Upgrade, UpgradedTo) values 
                  (@StyleId, @HeaderId, @HeaderName, @ConsumerFriendlyHeaderId, @ConsumerFriendlyHeaderName, 
                   @Description, @Upgrade, @UpgradedTo);
                   SET @NewId = SCOPE_IDENTITY()";

            const string deleteSQL1 = "delete from ChromeStandardEquipments where StyleId = @StyleId";
            const string deleteSQL2 = "delete from ChromeStandardEquipmentCatagories where StyleId = @StyleId";

            if (styleId == 0 || equipments.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    SqlCommand sqlCommand;
                    try
                    {
                        sqlConnection.Execute(deleteSQL1, new { styleId }, sqlTrans);
                        sqlConnection.Execute(deleteSQL2, new { styleId }, sqlTrans);

                        foreach (StandardEquipment eqp in equipments)
                        {
                            sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            sqlCommand.Parameters.Add(new SqlParameter("@StyleId", eqp.StyleId));
                            sqlCommand.Parameters.Add(new SqlParameter("@HeaderId", eqp.HeaderId));
                            sqlCommand.Parameters.Add(new SqlParameter("@HeaderName", eqp.HeaderName));
                            sqlCommand.Parameters.Add(new SqlParameter("@ConsumerFriendlyHeaderId", (object)eqp.ConsumerFriendlyHeaderId ?? DBNull.Value));
                            sqlCommand.Parameters.Add(new SqlParameter("@ConsumerFriendlyHeaderName", eqp.ConsumerFriendlyHeaderName));
                            sqlCommand.Parameters.Add(new SqlParameter("@Description", eqp.Description));
                            sqlCommand.Parameters.Add(new SqlParameter("@Upgrade", eqp.Upgrade));
                            sqlCommand.Parameters.Add(new SqlParameter("@UpgradedTo", eqp.UpgradedTo));
                            SqlParameter returnId = new SqlParameter("@NewId", System.Data.SqlDbType.Int)
                            {
                                Direction = System.Data.ParameterDirection.Output
                            };
                            sqlCommand.Parameters.Add(returnId);
                            Logger.Instance.Write($"inserting ChromeStandardEquipments( {eqp.Description} )");
                            sqlCommand.ExecuteNonQuery();
                            string newId = "" + sqlCommand.Parameters["@NewId"].Value;

                            foreach (var cat in eqp.StandardEquipmentCategories)
                            {
                                sqlCommand = new SqlCommand(@"
                                        insert into ChromeStandardEquipmentCatagories 
                                        (StandardEquipmentId, CategoryId, CategoryFlag, StyleId ) values 
                                        (@StandardEquipmentId, @CategoryId, @CategoryFlag, @StyleId )", sqlConnection, sqlTrans);
                                sqlCommand.Parameters.Add(new SqlParameter("@StandardEquipmentId", newId));
                                sqlCommand.Parameters.Add(new SqlParameter("@CategoryId", cat.Id));
                                sqlCommand.Parameters.Add(new SqlParameter("@CategoryFlag", (object)cat.Flag.ToString() ?? DBNull.Value));
                                sqlCommand.Parameters.Add(new SqlParameter("@StyleId", styleId));

                                Logger.Instance.Write($"Inserting ChromeStandardEquipmentCatagories( Id = {newId}, CatId={cat})");
                                sqlCommand.ExecuteNonQuery();
                            }
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeStandardEquipments /  ChromeStandardEquipmentCatagories for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertStyleColors(int styleId, List<StyleColor> colors)
        {
            const string insertSQL = @"
               insert into ChromeStyleColors 
               (StyleId, ExteriorInterior, ColorCode, ColorName, RGBHexCode, InstalledCause, InstalledDetail)
               values 
               (@StyleId, @ExteriorInterior, @ColorCode, @ColorName, @RGBHexCode, @InstalledCause, @InstalledDetail)";

            const string deleteSQL = "delete from ChromeStyleColors where StyleId = @StyleId";

            if (colors.Count <= 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (StyleColor c in colors)
                        {
                            sqlConnection.Execute(insertSQL, c, sqlTrans);
                            Logger.Instance.Write($"ChromeStyleColors color = {c.ColorName} for StyleId={c.StyleId} inserted");
                        }
                        sqlTrans.Commit();
                        Logger.Instance.Write($"ChromeStyleColors styleId = {styleId} committed");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeStyleColors for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }
        }
        public void InsertStyleGenericColors(int styleId, List<StyleGenericColor> colors)
        {
            const string insertSQL = @"
               insert into ChromeStyleGenericColors 
               (StyleId, ColorName, IsPrimary, InstalledCause, InstalledDetail)
               values 
               (@StyleId, @ColorName, @IsPrimary, @InstalledCause, @InstalledDetail)";

            const string deleteSQL = "delete from ChromeStyleGenericColors where StyleId = @StyleId";

            if (colors.Count <= 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (StyleGenericColor c in colors)
                        {
                            sqlConnection.Execute(insertSQL, c, sqlTrans);
                            Logger.Instance.Write($"ChromeStyleGenericColors color = {c.ColorName} inserted");
                        }
                        sqlTrans.Commit();
                        Logger.Instance.Write($"ChromeStyleGenericColors styleId = {styleId} committed");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeStyleGenericColors for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }
        }
        public void InsertEditorialContents(int styleId, EditorialContentSource[] contentSource)
        {
            Logger.Instance.Write($"inside StyleEditorialContent({styleId})");
            const string insertSQL = @"insert into ChromeStyleEditorialContent
                            ( StyleId, MimeType, ContentDescription, ContentValue, SourceName) values
                            ( @StyleId, @MimeType, @ContentDescription, @ContentValue, @SourceName)";

            const string deleteSQL = "delete from ChromeStyleEditorialContent where StyleId = @StyleId";

            if (styleId == 0 || contentSource == null || contentSource.Length == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(deleteSQL, new { styleId }, sqlTrans);
                        foreach (var content in contentSource)
                        {
                            foreach(var cont in content.editorialContents)
                            {
                                sqlConnection.Execute(insertSQL, cont, sqlTrans);
                                Logger.Instance.Write($"Inserting ChromeStyleEditorialContent( {content.sourceName})");
                            }
                        }
                        sqlTrans.Commit();
                        Logger.Instance.Write($"ChromeStyleEditorialContent for styleId = {styleId} commited");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                       Logger.Instance.Write($"ChromeStyleEditorialContent for styleId = {styleId} rollbacked with error: {ex.Message}");
                    }
                }
            }

        }
        public void InsertChromeStyle(ChromeStyle c, int dealerId)
        {
            const string insertSQL = @"
                insert into ChromeDecodedStyles(
                StyleId, StyleName, Acode, StockImage, ChromeImageID, BestMakeName, BestModelName, BestStyleName, BestTrimName,
                ModelYear, ModelName, MakeName, Cylinders, Engine, Displacement, FuelType,
                BodyType, VIN, WorldManufacturer, ViewImageCount, ColorizedImageCount
                ) values
                (@StyleId, @StyleName, @Acode, @StockImage, @ChromeImageID, @BestMakeName, @BestModelName, @BestStyleName, @BestTrimName,
                @ModelYear, @ModelName, @MakeName, @Cylinders, @Engine, @Displacement, @FuelType,
                @BodyType, @VIN, @WorldManufacturer, @ViewImageCount, @ColorizedImageCount)";

            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        sqlConnection.Execute(insertSQL, c, sqlTrans);
                        Logger.Instance.Write($"ChromeDecodedStyles for DealerId = {dealerId}, styleId = {c.StyleId} inserted");
                        sqlTrans.Commit();
                        Logger.Instance.Write($"ChromeDecodedStyles for DealerId = {dealerId}, styleId = {c.StyleId} commited");
                    }
                    catch (Exception ex)
                    {
                        sqlTrans.Rollback();
                        Logger.Instance.Write($"ChromeDecodedStyles for DealerId = {dealerId}, styleId = {c.StyleId} rollbacked with error: {ex.Message}");
                    }
                }
            }
        }
        //
        public List<Division> GetDivisions(int Year)
        {
            List<Division> divisions = new List<Division>();
            const string SelectSQL = @"
                            select DivisionId from ChromeDivisions where Year = @Year";
            using (SqlConnection conn = new SqlConnection(ConnString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(SelectSQL, conn))
                {
                    conn.Open();
                    SqlParameter paramYear = new SqlParameter("@Year", Year);
                    sqlCommand.Parameters.Add(paramYear);
                    try
                    {
                        SqlDataReader reader = sqlCommand.ExecuteReader();
                        while (reader.Read())
                        {
                            divisions.Add(new Division { DivisionId = Convert.ToInt32(reader["DivisionId"]) });
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        divisions = new List<Division>();
                    }
                }
            }
            return divisions;

        }
        public List<int> GetModelIds(int Year)
        {
            List<int> models = new List<int>();
            const string SelectSQL = @"
                            SELECT modelid FROM ChromeModels where year = @Year";
            using (SqlConnection conn = new SqlConnection(ConnString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(SelectSQL, conn))
                {
                    conn.Open();
                    SqlParameter paramYear = new SqlParameter("@Year", Year);
                    sqlCommand.Parameters.Add(paramYear);
                    try
                    {
                        SqlDataReader reader = sqlCommand.ExecuteReader();
                        while (reader.Read())
                        {
                            models.Add(Convert.ToInt32(reader["modelid"]));
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        models = new List<int>();
                    }
                }
            }
            return models;

        }
        public void InsertDivisions(List<Division> divisions)
        {
            const string insertSQL = @"insert into ChromeDivisions (Year, DivisionId, DivisionName) values (@Year, @DivisionId, @DivisionName)";
            if (divisions.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        foreach (Division division in divisions)
                        {
                            SqlCommand sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            SqlParameter paramYear = new SqlParameter("@Year", division.Year);
                            sqlCommand.Parameters.Add(paramYear);
                            SqlParameter paramDivisionId = new SqlParameter("@DivisionId", division.DivisionId);
                            sqlCommand.Parameters.Add(paramDivisionId);
                            SqlParameter paramDivisionName = new SqlParameter("@DivisionName", division.DivisionName);
                            sqlCommand.Parameters.Add(paramDivisionName);
                            sqlCommand.ExecuteNonQuery();
                            Logger.Instance.Write($"std opt = {division.DivisionName} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write("  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                        sqlTrans.Rollback();
                    }
                }
            }

        }
        public void InsertSubdivisions(List<Subdivision> subdivisions)
        {
            const string insertSQL = @"insert into ChromeSubDivisions (Year, SubDivisionId, SubDivisionName) values (@Year, @SubDivisionId, @SubDivisionName)";
            if (subdivisions.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        foreach (Subdivision subdivision in subdivisions)
                        {
                            SqlCommand sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            SqlParameter paramYear = new SqlParameter("@Year", subdivision.Year);
                            sqlCommand.Parameters.Add(paramYear);
                            SqlParameter paramSubDivisionId = new SqlParameter("@SubDivisionId", subdivision.SubdivisionId);
                            sqlCommand.Parameters.Add(paramSubDivisionId);
                            SqlParameter paramSubDivisionName = new SqlParameter("@SubDivisionName", subdivision.SubdivisionName);
                            sqlCommand.Parameters.Add(paramSubDivisionName);
                            sqlCommand.ExecuteNonQuery();
                            Logger.Instance.Write($"std opt = {subdivision.SubdivisionName} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write("  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                        sqlTrans.Rollback();
                    }
                }
            }

        }
        public void InsertModels(List<Model> models)
        {
            const string insertSQL = @"insert into ChromeModels (Year, ModelId, ModelName) values (@Year, @ModelId, @ModelName)";
            if (models.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        foreach (Model model in models)
                        {
                            SqlCommand sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            SqlParameter paramYear = new SqlParameter("@Year", model.Year);
                            sqlCommand.Parameters.Add(paramYear);
                            SqlParameter paramModelId = new SqlParameter("@ModelId", model.ModelId);
                            sqlCommand.Parameters.Add(paramModelId);
                            SqlParameter paramModelName = new SqlParameter("@ModelName", model.ModelName);
                            sqlCommand.Parameters.Add(paramModelName);
                            sqlCommand.ExecuteNonQuery();
                            Logger.Instance.Write($"std opt = {model.ModelName} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write("  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                        sqlTrans.Rollback();
                    }
                }
            }

        }
        public void InsertModelStyles(List<ModelStyle> modelstyles)
        {
            const string insertSQL = @"insert into ChromeModelStyles (ModelId, StyleId, StyleName) values (@ModelId, @StyleId, @StyleName)";
            if (modelstyles.Count == 0) return;
            using (SqlConnection sqlConnection = new SqlConnection(ConnString))
            {
                sqlConnection.Open();
                using (SqlTransaction sqlTrans = sqlConnection.BeginTransaction())
                {
                    try
                    {
                        foreach (ModelStyle modelstyle in modelstyles)
                        {
                            SqlCommand sqlCommand = new SqlCommand(insertSQL, sqlConnection, sqlTrans);
                            SqlParameter paramModelId = new SqlParameter("@ModelId", modelstyle.ModelId);
                            sqlCommand.Parameters.Add(paramModelId);
                            SqlParameter paramStyleId = new SqlParameter("@StyleId", modelstyle.StyleId);
                            sqlCommand.Parameters.Add(paramStyleId);
                            SqlParameter paramStyleName = new SqlParameter("@StyleName", modelstyle.StyleName);
                            sqlCommand.Parameters.Add(paramStyleName);
                            sqlCommand.ExecuteNonQuery();
                            Logger.Instance.Write($"std opt = {modelstyle.StyleName} inserted");
                        }
                        sqlTrans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.Instance.Write("  Database Rollback with error=");
                        Logger.Instance.Write(ex.Message);
                        sqlTrans.Rollback();
                    }
                }
            }
        }
        //
        private string GetPrimaryDesciption(OptionDescription[] descriptions)
        {
            string retval = "";
            foreach (var d in descriptions)
            {
                if (d.type == OptionDescriptionType.PrimaryName || d.type == OptionDescriptionType.Extended)
                    retval = retval + d.description + " ";
            }
            return retval;
        }

    }
}
