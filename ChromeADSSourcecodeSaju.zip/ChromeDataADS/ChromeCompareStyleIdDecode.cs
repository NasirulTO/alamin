﻿using ChromeCompareServiceReference;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ChromeDataADS
{
    class ChromeCompareStyleIdDecode
    {
        readonly DatabaseManager db;
        readonly ChromeCompareServiceReference.AccountInfo accountInfo;
        public ChromeCompareStyleIdDecode(ChromeCompareServiceReference.AccountInfo accountInfo, DatabaseManager db)
        {
            this.accountInfo = accountInfo;
            this.db = db;
        }
        public void ProcessChromeCompareService(int styleId)
        {
            if (styleId <= 0) // null or not valid
            {
                Console.WriteLine($"Wrong StyleId  {styleId} provided)");
                Logger.Instance.Write($"Wrong StyleId  {styleId} provided)");
                return;
            }
            Task<getConfigurationResponse> vehicleResponse = ConfigurationByStyleId(styleId);
            try
            {
                vehicleResponse.Wait();
            }
            catch (Exception ex)
            {
                Logger.Instance.Write($"Status = {vehicleResponse.Status.ToString()} returned for {styleId})");
                Logger.Instance.Write($"Error = {ex.Message}");
                return;
            }
            Logger.Instance.Write(vehicleResponse.Result.ConfigurationElement.configuration.style.marketingCopy?? "style.Marketing Copy not found");
            db.InsertStandardEquipments(styleId, GetStandardEquipments(styleId, vehicleResponse.Result.ConfigurationElement.configuration.standardEquipment));
            db.InsertTechnicalSpecs(styleId, GetTechnicalSpec(styleId, vehicleResponse.Result.ConfigurationElement.configuration.technicalSpecifications));
            db.InsertConsumerInfo(styleId, GetConsumerInfo(styleId, vehicleResponse.Result.ConfigurationElement.configuration.structuredConsumerInformation));
            db.InsertOptions(styleId, vehicleResponse.Result.ConfigurationElement.configuration.options);
            db.InsertEditorialContents(styleId, vehicleResponse.Result.ConfigurationElement.configuration.editorialContentSources);
        }

        private object GetOptions(int styleId, Option[] options)
        {
            return options;
        }

        private List<ConsumerInfo> GetConsumerInfo(int styleId, StructuredConsumerInformation[] consumerInformations)
        {
            List<ConsumerInfo> consumerInfos = new List<ConsumerInfo>();
            foreach (var cis in consumerInformations)
            {
                foreach (var itm in cis.items)
                {
                    ConsumerInfo ci = new ConsumerInfo
                    {
                        StyleId = styleId,
                        TypeName = cis.typeName
                    };
                    ci.ItemName = itm.name;
                    ci.ItemValue = itm.value;
                    ci.ConditionNote = itm.conditionNote ?? "";
                    ci.Sequence = itm.sequence;
                    consumerInfos.Add(ci);
                }

            }
            return consumerInfos;
        }

        private List<StandardEquipment> GetStandardEquipments(int styleId, Standard[] standards)
        {
            List<StandardEquipment> options = new List<StandardEquipment>();
            foreach (var s in standards)
            {

                StandardEquipment se = new StandardEquipment
                {
                    StyleId = styleId,
                    HeaderId =  s.headerId,
                    HeaderName = s.headerName ?? "",
                    Description = s.description ?? "",
                    Upgrade = s.upgrade,
                    UpgradedTo = s.upgradedTo ?? "",
                    StandardEquipmentCategories = new List<StandardEquipmentCategory>()
                };
                if (s.consumerFriendlyHeaderId != null) se.ConsumerFriendlyHeaderId = s.consumerFriendlyHeaderId;
                if (s.consumerFriendlyHeaderName != null) se.ConsumerFriendlyHeaderName = s.consumerFriendlyHeaderName;

                if (s.categories != null)
                {
                    foreach (Category c in s.categories)
                            se.StandardEquipmentCategories.Add(
                                new StandardEquipmentCategory {
                                    Id = c.categoryId,
                                    Flag = c.categoryFlag
                                });
                }
                options.Add(se);

            }
            return options;
        }

        private object GetResponseFactoryOptions(int styleId, Option[] options)
        {
            throw new NotImplementedException();
        }

        private List<TechnicalSpecification> GetTechnicalSpec(int styleId, ChromeCompareServiceReference.TechnicalSpecification[] technicalSpecifications)
        {
            List<TechnicalSpecification> specs = new List<TechnicalSpecification>();
            foreach (var tspec in technicalSpecifications)
            {
                TechnicalSpecification ts = new TechnicalSpecification
                {
                    StyleId = styleId,
                    GroupId = tspec.groupId,
                    GroupName = tspec.groupName,
                    HeaderId = tspec.headerId,
                    HeaderName = tspec.headerName,
                    TitleId = tspec.titleId,
                    TitleName = tspec.titleName,
                    Value = tspec.value,
                    Unit = "",
                    UpGrade = tspec.upgrade,
                    Sequence = tspec.sequence
                };
                ts.Unit = tspec.measurementUnit ?? "";
                specs.Add(ts);
            }
            return specs;
        }

        private async Task<getConfigurationResponse> ConfigurationByStyleId(int styleId)
        {
            AutomotiveConfigCompareService4gPortTypeClient client = new AutomotiveConfigCompareService4gPortTypeClient();
            ConfigurationByStyleIdRequest req = new ConfigurationByStyleIdRequest
            {
                accountInfo = accountInfo
            };
            req.styleId = styleId;
            req.returnParameters = new ReturnParameters()
            {
                includeStandards = true,
                includeOptions = true,
                includeOptionDescriptions = true,
                includeEditorialContent = true,
                includeStructuredConsumerInfo = true,
                includeConfigurationChecklist = true,
                includeTechSpecs = true,
                includeStylePackages = true
            };

            getConfigurationResponse result = await client.getConfigurationByStyleIdAsync(req);
            return result;
        }
    }
}
