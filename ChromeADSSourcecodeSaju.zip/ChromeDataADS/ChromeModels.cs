﻿using ChromeServiceReference;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ChromeDataADS
{
    internal class ChromeModels
    {
        private readonly DatabaseManager db;
        private ChromeServiceReference.AccountInfo accountInfo;

        public ChromeModels(ChromeServiceReference.AccountInfo accountInfo, DatabaseManager db)
        {
            this.db = db;
            this.accountInfo = accountInfo;
        }
        public void LoadModelsByYear(int modelYear)
        {
            if (modelYear < 1990) //  not valid
            {
                Console.WriteLine("Skipped Chrome ADS. Year should be after 1989.");
                Logger.Instance.Write("Skipped Chrome ADS. Year should be after 1989.");
                return;
            }
            List<Division> divisions = db.GetDivisions(modelYear);
            foreach (Division division in divisions)
            {
                Task<getModelsResponse> modelsResponse = GetModelsFromDivision(modelYear, division.DivisionId);
                modelsResponse.Wait();
                if (modelsResponse.Result.Models.responseStatus.responseCode == ResponseStatusResponseCode.Successful)
                    ProcessModels(modelYear, modelsResponse.Result.Models.model);
            }
        }

        private void ProcessModels(int modelYear, IdentifiedString[] identifiedStrings)
        {
            List<Model> models = new List<Model>();
            foreach (IdentifiedString identifiedString in identifiedStrings)
            {
                models.Add(new Model
                {
                    Year = modelYear,
                    ModelId = identifiedString.id,
                    ModelName = identifiedString.Value
                });
            }
            db.InsertModels(models);
        }

        private async Task<getModelsResponse> GetModelsFromDivision(int modelYear, int divId)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            ModelsRequest req = new ModelsRequest
            {
                accountInfo = accountInfo
            };
            req.modelYear = modelYear;
            req.Item = divId;
            req.ItemElementName = ChromeServiceReference.ItemChoiceType.divisionId;
            getModelsResponse result = await client.getModelsAsync(req);
            return result;

        }

        private async Task<getModelsResponse> GetModelsFromSubdivision(int modelYear, int subdivId)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            ModelsRequest req = new ModelsRequest
            {
                accountInfo = accountInfo
            };
            req.modelYear = modelYear;
            req.Item = subdivId;
            req.ItemElementName = ChromeServiceReference.ItemChoiceType.subdivisionId;
            getModelsResponse result = await client.getModelsAsync(req);
            return result;

        }

    }
}