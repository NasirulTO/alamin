﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public static class FileDownLoader
    {

        public static  byte[] GetBytesFromUrl(string url)
        {
            byte[] b = null;
            try
            {
                System.Net.WebRequest myReq = System.Net.WebRequest.Create(url);
                System.Net.WebResponse myResp = myReq.GetResponse();

                System.IO.Stream stream = myResp.GetResponseStream();

                using (System.IO.BinaryReader br = new System.IO.BinaryReader(stream))
                {
                    b = br.ReadBytes(100000000);
                    br.Close();
                }
                myResp.Close();
            }
            catch (Exception ex)
            {
                Logger.Instance.Write("error in GetBytesFromUrl = " + ex);
            }
            return b;
        }

        public static  void WriteBytesToFile(string fileName, byte[] content)
        {
            try
            {
                System.IO.FileStream fs = new System.IO.FileStream(fileName, System.IO.FileMode.Create);
                System.IO.BinaryWriter w = new System.IO.BinaryWriter(fs);
                w.Write(content);
                fs.Close();
                fs.Dispose();
                fs = null;
                w.Close();
                w = null;
            }
            catch (Exception ex)
            {
                Logger.Instance.Write("error in WriteBytesToFile = " + ex);
            }
        }

    }
}
