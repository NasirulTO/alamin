﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class GalleryImage
    {
        public int Id { get; set; }
        public string ImageType { get; set; } 
        public int StyleId { get; set; }
        public string Url { get; set; }
        public string ShotCode { get; set; }
        public string BackgroundDescription { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public string PrimaryColorOptionCode { get; set; }
        public string PrimaryRGBHexCode { get; set; }
    }
}
