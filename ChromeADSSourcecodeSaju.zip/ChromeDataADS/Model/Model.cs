﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class Model
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public int ModelId { get; set; }
        public string ModelName { get; set; }
    }
}
