﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class AdsFactoryOption
    {
        public int Id { get; set; } 
        public int StyleId { get; set; } 
        public int HeaderId { get; set; } 
        public string HeaderName { get; set; }
        public string Description { get; set; } 
        public double? Price { get; set; }
        public string InstalledCause { get; set; }
        public string InstalledDetail { get; set; }
        public string ChromeCode { get; set; }
        public string OEMCode { get; set; } 
        public string AltOptionCode { get; set; } 
        public bool? IsStandard { get; set; }
        public int? OptionKindId { get; set; }
        public string UTF { get; set; } 
        public bool? IsFleetOnly { get; set; }
        public string RGBHexCode { get; set; }
    }
}
