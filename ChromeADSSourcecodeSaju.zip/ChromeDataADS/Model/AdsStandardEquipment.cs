﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class AdsStandardEquipment
    {
        public int StyleId { get; set; } 
        public string Description { get; set; } 
        public string Header { get; set; } 
        public string InstalledCause { get; set; }
        public string InstalledDetail { get; set; }
        public List<int> AdsStandardEquipmentCategories { get; set; }
    }
}
