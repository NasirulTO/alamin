﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class AdsConsumerInfo
    {
        public int Id { get; set; } 
        public int StyleId { get; set; } 
        public int HeaderId { get; set; } 
        public string HeaderName { get; set; } 
        public string ItemName { get; set; } 
        public string ItemValue { get; set; } 
    }
}
