﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class StandardEquipment
    {
        public int Id { get; internal set; }
        public int StyleId { get; internal set; }
        public string Description { get; internal set; }
        public int HeaderId { get; internal set; }
        public string HeaderName { get; internal set; }
        public int? ConsumerFriendlyHeaderId { get; internal set; }
        public string ConsumerFriendlyHeaderName { get; internal set; }
        public bool Upgrade { get; internal set; }
        public string UpgradedTo { get; internal set; }
        public List<StandardEquipmentCategory> StandardEquipmentCategories { get; internal set; }
    }
}
