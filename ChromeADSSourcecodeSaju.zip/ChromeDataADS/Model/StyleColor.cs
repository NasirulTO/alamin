﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class StyleColor
    {
        public int Id { get; set; }
        public int StyleId { get; set; }
        public string ExteriorInterior { get; set; }
        public string ColorCode { get; set; }
        public string ColorName { get; set; }
        public string RGBHexCode { get; set; }
        public string InstalledCause { get; set; }
        public string InstalledDetail { get; set; }

    }
}
