﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class Asset
    {
        public int AssetId { get; set; }
        public int DealerId { get; set; }
        public string Vin { get; set; }
        public int Year { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string ExteriorColor { get; set; }
        public string Trim { get; set; } 
        public string TransmissionType { get; set; }
        public string StyleName { get; set; } 
        public string Acode { get; set; }
        public int StyleId { get; set; }
        public string ChromeExtColorOptionCode { get; set; }
        public string ChromeExtRGBHexCode { get; set; }
        public string ChromeExtColorName { get; set; }
        public string ChromeImageId { get; set; }
        public string ChromeImageUrl { get; set; }
    }
}
