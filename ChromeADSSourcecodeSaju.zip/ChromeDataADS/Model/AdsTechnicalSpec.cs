﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class AdsTechnicalSpec
    {
        public int StyleId { get; set; }
        public int TitleId { get; set; }
        public double? RangeMin { get; set; }
        public double? RangeMax { get; set; }
        public string Value { get; set; }
        public string Condition { get; set; }
    }
}
