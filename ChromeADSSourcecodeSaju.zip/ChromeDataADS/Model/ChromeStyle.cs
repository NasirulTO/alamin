﻿namespace ChromeDataADS
{
    public class ChromeStyle
    {
        public int StyleId { get; set; } = 0;
        public string StyleName { get; set; } = "";
        public string Acode { get; set; } = "";
        public string StockImage { get; set; } = "";
        public string ChromeImageID { get; set; } = "";
        public string BestMakeName { get; set; } = "";
        public string BestModelName { get; set; } = "";
        public string BestStyleName { get; set; } = "";
        public string BestTrimName { get; set; } = "";
        public int ModelYear { get; set; } = 0;
        public string ModelName { get; set; } = "";
        public string MakeName { get; set; } = "";
        public int Cylinders { get; set; } = 0;
        public string Engine { get; set; } = "";
        public string Displacement { get; set; } = "";
        public string FuelType { get; set; } = "";
        public string BodyType { get; set; } = "";
        public string VIN { get; set; } = "";
        public string WorldManufacturer { get; set; } = "";
        public int ViewImageCount { get; set; } = 0;
        public int ColorizedImageCount { get; set; } = 0;


    }
}