﻿using ChromeCompareServiceReference;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class StandardEquipmentCategory
    {
        public int Id { get; set; }
        public CategoryFlag? Flag { get; set; }
    }
}
