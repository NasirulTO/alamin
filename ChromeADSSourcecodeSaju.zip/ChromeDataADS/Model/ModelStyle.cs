﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class ModelStyle
    {
    public int ModelId { get; set; }
    public int StyleId { get; set; }
    public string  StyleName { get; set; }
}
}
