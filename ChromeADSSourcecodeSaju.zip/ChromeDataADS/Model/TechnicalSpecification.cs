﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public  class TechnicalSpecification
    {
        public int Id { get; set; }
        public int StyleId { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public int HeaderId { get; set; }
        public string HeaderName { get; set; }
        public int TitleId { get; set; }
        public string TitleName { get; set; }
        public string Value { get; set; }
        public string Unit { get; set; }
        public bool UpGrade { get; set; }
        public int Sequence { get; set; }
    }
}
