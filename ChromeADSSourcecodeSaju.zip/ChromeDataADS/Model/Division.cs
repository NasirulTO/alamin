﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class Division
    {
        public int Id {get; set;}
        public int Year { get; set; }
        public int DivisionId { get; set; }
        public string DivisionName { get; set; }

    }
}
