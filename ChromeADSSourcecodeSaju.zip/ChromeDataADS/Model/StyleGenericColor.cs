﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class StyleGenericColor
    {
        public int Id { get; set; }
        public int StyleId { get; set; }
        public string ColorName { get; set; }
        public bool IsPrimary { get; set; }
        public string InstalledCause { get; set; }
        public string InstalledDetail { get; set; }
    }
}
