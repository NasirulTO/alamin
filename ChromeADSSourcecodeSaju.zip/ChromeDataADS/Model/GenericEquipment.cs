﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChromeDataADS
{
    public class AdsGenericEquipment
    {
        public int StyleId { get; set; }
        public int CategoryId { get; set; } 
        public string InstalledCause { get; set; }
        public string InstalledDetail { get; set; }
    }
}
