﻿using ChromeServiceReference;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ChromeDataADS
{
    internal class ChromeDivisions
    {
        private readonly DatabaseManager db;
        private ChromeServiceReference.AccountInfo accountInfo;

        public ChromeDivisions(ChromeServiceReference.AccountInfo accountInfo,DatabaseManager db)
        {
            this.db = db;
            this.accountInfo = accountInfo;
        }
        public void LoadDivisionsByYear(int modelYear)
        {
            if (modelYear < 1990) //  not valid
            {
                Console.WriteLine("Skipped Chrome ADS. Year should be after 1989.");
                Logger.Instance.Write("Skipped Chrome ADS. Year should be after 1989.");
                return;
            }
            Task<getDivisionsResponse> divisionsResponse = GetDivisions(modelYear);
            divisionsResponse.Wait();
            if (divisionsResponse.Result.Divisions.responseStatus.responseCode == ResponseStatusResponseCode.Successful)
                ProcessDivisions(modelYear, divisionsResponse.Result.Divisions.division);

        }

        private void ProcessDivisions(int modelYear, IdentifiedString[] identifiedStrings)
        {
            List<Division> divisions = new List<Division>();
            foreach(IdentifiedString identifiedString in identifiedStrings)
            {
                divisions.Add(new Division
                {
                    Year = modelYear,
                    DivisionId = identifiedString.id,
                    DivisionName = identifiedString.Value
                });
            }
            db.InsertDivisions(divisions);
        }

        private async Task<getDivisionsResponse> GetDivisions(int modelYear)
        {
            Description7bPortTypeClient client = new Description7bPortTypeClient();
            DivisionsRequest req = new DivisionsRequest
            {
                accountInfo = accountInfo
            };
            req.modelYear = modelYear;

            getDivisionsResponse result = await client.getDivisionsAsync(req);
            return result;

        }

    }
}